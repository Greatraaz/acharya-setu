@php
    $myNote = ($item->notes ?? collect())
        ->where('author_id', auth()->id())
        ->where('is_shared', false)
        ->where('type', 'note')
        ->first();
@endphp
<div class="card session-detail-card cs-panel cs-panel--tight" id="my-mock-notes" data-save-url="{{ route('mock-interviews.notes.save', $item->id) }}">
    <div class="session-detail-card-head" style="margin-bottom:10px;">
        <h3>My Personal Notes</h3>
        <span class="session-detail-card-hint">Private — only you can see these</span>
    </div>
    <textarea id="my-mock-note-content" class="form-textarea" rows="6"
              placeholder="Notes you took during the mock interview…">{{ $myNote->content ?? '' }}</textarea>
    <div class="mi-notes-actions" style="display:flex;align-items:center;justify-content:space-between;margin-top:12px;gap:12px;flex-wrap:wrap;">
        <span id="my-mock-note-status" style="font-size:12px;color:var(--text-3);"></span>
        <button type="button" class="btn btn-primary btn-sm" id="my-mock-note-save" style="margin-left:auto;">Save Notes</button>
    </div>
</div>

@once
@push('scripts')
<script>
(function () {
    const wrap = document.getElementById('my-mock-notes');
    if (!wrap) return;

    const saveUrl = wrap.dataset.saveUrl;
    const textarea = document.getElementById('my-mock-note-content');
    const statusEl = document.getElementById('my-mock-note-status');
    const saveBtn = document.getElementById('my-mock-note-save');
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';

    async function saveMyNote() {
        saveBtn.disabled = true;
        statusEl.textContent = 'Saving…';
        statusEl.style.color = 'var(--text-2)';
        try {
            const res = await fetch(saveUrl, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': csrf,
                    'X-Requested-With': 'XMLHttpRequest',
                },
                body: JSON.stringify({ content: textarea.value }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.message || 'Could not save notes.');
            statusEl.textContent = 'Saved';
            statusEl.style.color = 'var(--success)';
            if (window.showToast) showToast('success', 'Notes saved.');
        } catch (e) {
            statusEl.textContent = e.message || 'Save failed';
            statusEl.style.color = 'var(--error)';
            if (window.showToast) showToast('error', e.message || 'Could not save notes.');
        } finally {
            saveBtn.disabled = false;
        }
    }

    saveBtn?.addEventListener('click', saveMyNote);
})();
</script>
@endpush
@endonce
