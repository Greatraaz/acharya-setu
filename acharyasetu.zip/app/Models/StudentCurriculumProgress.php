<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StudentCurriculumProgress extends Model
{
    protected $fillable = [
        'user_id', 'item_type', 'item_id', 'is_completed', 'completed_at',
        'submission_url', 'submission_text', 'submission_status',
        'mentor_feedback', 'reviewed_at',
    ];

    protected $casts = [
        'is_completed' => 'boolean',
        'completed_at' => 'datetime',
        'reviewed_at'  => 'datetime',
    ];

    /** Task/MCQ statuses that increase journey progress %. */
    public const PROGRESS_COUNTED_STATUSES = ['submitted', 'approved'];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /** Absolute URL for opening a submitted file/link in browser. */
    public function submissionLink(): ?string
    {
        $url = trim((string) ($this->submission_url ?? ''));
        if ($url === '') {
            return null;
        }

        if (str_starts_with($url, 'http://') || str_starts_with($url, 'https://')) {
            return $url;
        }

        return url($url);
    }

    /**
     * Whether this row currently increases journey progress.
     * Tasks/MCQs: submitted (awaiting review) or approved. Rejected does not count.
     */
    public function contributesToProgress(): bool
    {
        if (in_array($this->item_type, ['task', 'mcq'], true)) {
            return $this->is_completed
                || in_array((string) $this->submission_status, self::PROGRESS_COUNTED_STATUSES, true);
        }

        return (bool) $this->is_completed;
    }

    /**
     * Scope: rows that currently count toward progress %.
     * - task/mcq: is_completed OR submission_status in submitted|approved
     * - other types: is_completed only
     */
    public function scopeCountsTowardProgress(Builder $query): Builder
    {
        return $query->where(function (Builder $q) {
            $q->where(function (Builder $inner) {
                $inner->whereIn('item_type', ['task', 'mcq'])
                    ->where(function (Builder $s) {
                        $s->where('is_completed', true)
                            ->orWhereIn('submission_status', self::PROGRESS_COUNTED_STATUSES);
                    });
            })->orWhere(function (Builder $inner) {
                $inner->whereNotIn('item_type', ['task', 'mcq'])
                    ->where('is_completed', true);
            });
        });
    }

    /**
     * Scope for task/mcq items only that count toward progress.
     */
    public function scopeTaskOrMcqCountsTowardProgress(Builder $query): Builder
    {
        return $query->whereIn('item_type', ['task', 'mcq'])
            ->where(function (Builder $s) {
                $s->where('is_completed', true)
                    ->orWhereIn('submission_status', self::PROGRESS_COUNTED_STATUSES);
            });
    }

    /**
     * Upsert a progress record for a user.
     */
    public static function markComplete(int $userId, string $type, int $itemId, array $extra = []): static
    {
        $isCompleted = array_key_exists('is_completed', $extra)
            ? (bool) $extra['is_completed']
            : true;

        $payload = array_merge($extra, [
            'is_completed' => $isCompleted,
            'completed_at' => $isCompleted ? ($extra['completed_at'] ?? now()) : null,
        ]);

        return static::updateOrCreate(
            ['user_id' => $userId, 'item_type' => $type, 'item_id' => $itemId],
            $payload
        );
    }

    /**
     * Calculate overall progress for a user across a full stream.
     */
    public static function getOverallProgress(int $userId, int $streamId): array
    {
        $months = CurriculumMonth::where('stream_id', $streamId)->with('weeks')->get();
        $total  = 0;
        $done   = 0;

        foreach ($months as $month) {
            foreach ($month->weeks as $week) {
                $p      = $week->getProgressForUser($userId);
                $total += $p['total'];
                $done  += $p['completed'];
            }
        }

        return [
            'percent'   => $total ? (int) round($done / $total * 100) : 0,
            'completed' => $done,
            'total'     => $total,
        ];
    }

    /**
     * Full mentee progress summary: tasks, MCQs, materials, videos.
     * Pass $mentorId to scope to that mentor's curriculum / videos only.
     *
     * Task/MCQ "completed" here means counts toward progress (submitted or approved).
     */
    public static function getMenteeProgressSummary(int $menteeId, ?int $mentorId = null): array
    {
        $taskQuery = CurriculumTask::where('mentee_id', $menteeId)->where('is_active', true);
        $mcqQuery  = CurriculumMcq::where('mentee_id', $menteeId)->where('is_active', true);
        $materialQuery = TaskSupportingMaterial::where('mentee_id', $menteeId)->where('is_active', true);
        $videoQuery = MentorVideoFile::whereHas('mentorVideo', function ($q) use ($mentorId) {
            $q->where('is_active', true);
            if ($mentorId) {
                $q->where('mentor_id', $mentorId);
            }
        });

        if ($mentorId) {
            $streamScope = fn ($q) => $q->where('mentor_id', $mentorId)->where('mentee_id', $menteeId);
            $taskQuery->whereHas('week.month.stream', $streamScope);
            $mcqQuery->whereHas('week.month.stream', $streamScope);
            $materialQuery->where('mentor_id', $mentorId);
        }

        $taskIds = $taskQuery->pluck('id');
        $mcqIds  = $mcqQuery->pluck('id');
        $materialIds = $materialQuery->pluck('id');
        $videoFileIds = $videoQuery->pluck('id');

        $tasksCompleted = static::where('user_id', $menteeId)
            ->where('item_type', 'task')
            ->whereIn('item_id', $taskIds)
            ->taskOrMcqCountsTowardProgress()
            ->count();

        $mcqsCompleted = static::where('user_id', $menteeId)
            ->where('item_type', 'mcq')
            ->whereIn('item_id', $mcqIds)
            ->taskOrMcqCountsTowardProgress()
            ->count();

        $materialsCompleted = static::where('user_id', $menteeId)
            ->where('item_type', 'material')
            ->where('is_completed', true)
            ->whereIn('item_id', $materialIds)
            ->count();

        $tasksTotal = $taskIds->count();
        $mcqsTotal  = $mcqIds->count();
        $materialsTotal = $materialIds->count();
        $videosTotal  = $videoFileIds->count();
        $videosWatched = MentorVideoWatch::where('mentee_id', $menteeId)
            ->whereIn('mentor_video_file_id', $videoFileIds)
            ->count();

        $tasksBreakdown = [
            'total'     => $tasksTotal,
            'completed' => $tasksCompleted,
            'percent'   => $tasksTotal ? (int) round($tasksCompleted / $tasksTotal * 100) : 0,
        ];

        $mcqsBreakdown = [
            'total'     => $mcqsTotal,
            'completed' => $mcqsCompleted,
            'percent'   => $mcqsTotal ? (int) round($mcqsCompleted / $mcqsTotal * 100) : 0,
        ];

        $videosBreakdown = [
            'total'   => $videosTotal,
            'watched' => $videosWatched,
            'percent' => $videosTotal ? (int) round($videosWatched / $videosTotal * 100) : 0,
        ];

        $materialsBreakdown = [
            'total'     => $materialsTotal,
            'completed' => $materialsCompleted,
            'percent'   => $materialsTotal ? (int) round($materialsCompleted / $materialsTotal * 100) : 0,
        ];

        $overallTotal     = $tasksTotal + $mcqsTotal + $materialsTotal + $videosTotal;
        $overallCompleted = $tasksCompleted + $mcqsCompleted + $materialsCompleted + $videosWatched;

        $pendingSubmissions = static::where('user_id', $menteeId)
            ->whereIn('item_type', ['task', 'mcq'])
            ->where('submission_status', 'submitted')
            ->where(function ($q) use ($taskIds, $mcqIds) {
                $q->where(function ($inner) use ($taskIds) {
                    $inner->where('item_type', 'task')->whereIn('item_id', $taskIds);
                })->orWhere(function ($inner) use ($mcqIds) {
                    $inner->where('item_type', 'mcq')->whereIn('item_id', $mcqIds);
                });
            })
            ->count();

        return [
            'overall' => [
                'total'     => $overallTotal,
                'completed' => $overallCompleted,
                'percent'   => $overallTotal ? (int) round($overallCompleted / $overallTotal * 100) : 0,
            ],
            'tasks'  => $tasksBreakdown,
            'mcqs'   => $mcqsBreakdown,
            'materials' => $materialsBreakdown,
            'videos' => $videosBreakdown,
            'pending_submissions' => $pendingSubmissions,
        ];
    }
}
