<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class AppSetting extends Model
{
    protected $primaryKey = 'key';
    public $incrementing  = false;
    protected $keyType    = 'string';
 
    protected $fillable = ['key', 'value'];
 
    /**
     * Get a config value by key (with optional default).
     * Results are cached for 60 minutes.
     */
    public static function allCached(): array
    {
        return Cache::remember('app_configurations', 3600, function () {
            return static::all()->pluck('value', 'key')->toArray();
        });
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $all = static::allCached();

        return $all[$key] ?? $default;
    }
 
    /**
     * Set a config value and clear cache.
     */
    public static function set(string $key, mixed $value): void
    {
        static::updateOrCreate(['key' => $key], ['value' => $value]);
        Cache::forget('app_configurations');
    }

    public static function isMaintenanceMode(): bool 
    {
         return static::get('maintenance_mode', '0') === '1'; 
    }
    
    public static function isTwoFactorEnabled(): bool 
    {
         return static::get('two_factor_auth', '0') === '1'; 
    }
    
    public static function isEmailVerificationEnabled(): bool 
    {
         return static::get('email_verification', '1') === '1'; 
    }
    
    public static function isUserRegistrationEnabled(): bool 
    {
         return static::get('user_registration', '1') === '1'; 
    }
    


    // ── Helpers for specific setting groups ───────────────────
 
    /** Mail / SMTP settings */
    public static function mail(): array
    {
        $s = static::allCached();
        return [
            'driver'     => $s['mail_driver']     ?? $s['mail_mailer']  ?? 'smtp',
            'host'       => $s['smtp_host']        ?? '',
            'port'       => (int) ($s['smtp_port'] ?? 587),
            'encryption' => $s['smtp_encryption']  ?? 'tls',
            'username'   => $s['smtp_username']    ?? '',
            'password'   => $s['smtp_password']    ?? '',
            'from_address' => $s['mail_from_address'] ?? 'hello@vedrix.com',
            'from_name'    => $s['mail_from_name']    ?? ($s['app_name'] ?? 'Vedrix'),
        ];
    }
 
    /** Razorpay settings */
    public static function razorpay(): array
    {
        $s = static::allCached();
        $mode = $s['razorpay_mode'] ?? 'test';

        $key = static::firstNonEmpty([
            $s["razorpay_{$mode}_key"] ?? null,
            $s['razorpay_key_id'] ?? null,
            $s['razorpay_key'] ?? null,
            config('services.razorpay.key'),
            env('RAZORPAY_KEY_ID'),
        ]);

        $secret = static::firstNonEmpty([
            static::decryptIfNeeded($s["razorpay_{$mode}_secret"] ?? null),
            static::decryptIfNeeded($s['razorpay_key_secret'] ?? null),
            static::decryptIfNeeded($s['razorpay_secret'] ?? null),
            config('services.razorpay.secret'),
            env('RAZORPAY_KEY_SECRET'),
        ]);

        return [
            'mode'    => $mode,
            'enabled' => static::toBool($s['razorpay_enabled'] ?? false),
            'key'     => $key,
            'secret'  => $secret,
        ];
    }

    private static function firstNonEmpty(array $values): string
    {
        foreach ($values as $value) {
            if ($value !== null && $value !== '') {
                return (string) $value;
            }
        }

        return '';
    }

    private static function decryptIfNeeded(?string $value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }

        $current = $value;

        // Secrets may have been encrypted more than once when re-saving settings.
        for ($i = 0; $i < 3; $i++) {
            $looksEncrypted = strlen($current) > 80 || str_starts_with($current, 'eyJpdiI6');
            if (! $looksEncrypted) {
                return $current;
            }

            try {
                $plain = decrypt($current);
                if (! is_string($plain) || $plain === '') {
                    return null;
                }
                $current = $plain;
            } catch (\Throwable) {
                // Undecryptable ciphertext — force re-entry in admin settings.
                return null;
            }
        }

        return strlen($current) > 80 ? null : $current;
    }

    private static function toBool(mixed $value): bool
    {
        return in_array((string) $value, ['1', 'true', 'yes', 'on'], true);
    }
 
    /** MSG91 SMS settings */
    public static function msg91(): array
    {
        $s = static::allCached();
        return [
            'auth_key'    => $s['msg91_auth_key']        ?? '',
            'sender_id'   => $s['msg91_sender_id']       ?? 'VEDRIX',
            'route'       => $s['msg91_route']            ?? '4',
            'template_id' => $s['msg91_otp_template_id'] ?? '',
        ];
    }
 
    /** Fast2SMS settings */
    public static function fast2sms(): array
    {
        $s = static::allCached();
        return [
            'api_key' => $s['fast2sms_api_key'] ?? '',
            'route'   => $s['fast2sms_route']   ?? 'dlt_manual',
        ];
    }
 
    /** Active SMS provider name */
    public static function smsProvider(): string
    {
        return static::get('sms_active_provider', 'msg91');
    }
 
    /** Agora video settings */
    public static function agora(): array
    {
        $s = static::allCached();
        return [
            'app_id'      => $s['agora_app_id']          ?? '',
            'app_cert'    => $s['agora_app_certificate']  ?? '',
            'token_expiry'=> (int)($s['agora_token_expiry'] ?? 3600),
        ];
    }
 
    /** App general settings */
    public static function app(): array
    {
        $s = static::allCached();
        return [
            'name'              => $s['app_name']      ?? 'Vedrix',
            'url'               => $s['app_url']       ?? config('app.url'),
            'timezone'          => $s['timezone']      ?? 'Asia/Kolkata',
            'currency'          => $s['default_currency'] ?? 'INR',
            'currency_symbol'   => $s['currency_symbol']  ?? '₹',
            'date_format'       => $s['date_format']   ?? 'd/m/Y',
            'maintenance_mode'  => (bool)($s['maintenance_mode'] ?? false),
        ];
    }

    /** Seller / invoice billing details */
    public static function billing(): array
    {
        $s = static::allCached();
        $app = static::app();

        return [
            'company_name' => $s['invoice_company_name'] ?? ($app['name'] ?? 'Vedrix'),
            'gstin'        => $s['invoice_gstin'] ?? '',
            'address'      => $s['invoice_address'] ?? '',
            'email'        => $s['invoice_email'] ?? ($s['contact_email'] ?? ''),
            'phone'        => $s['invoice_phone'] ?? ($s['support_phone'] ?? ''),
            'prefix'       => $s['invoice_prefix'] ?? 'INV',
        ];
    }
}
