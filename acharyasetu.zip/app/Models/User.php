<?php

namespace App\Models;
 
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use App\Traits\HasSubscription;
use App\Traits\HasWallet;
use App\Casts\PreferencesCast;
 
class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes, HasSubscription, HasWallet;
 
    // ── Mentor status constants ───────────────────────────────
    const MENTOR_STATUS_PENDING  = 'pending';
    const MENTOR_STATUS_APPROVED = 'approved';
    const MENTOR_STATUS_REJECTED = 'rejected';
    const MENTOR_STATUS_SUSPENDED = 'suspended';
 
    // ── Onboarding steps ─────────────────────────────────────
    // MENTOR steps: 0=role, 1=personal, 2=professional, 3=expertise, 4=rates, 5=done
    // MENTEE steps: 0=role, 1=profile, 2=education, 3=career goals, 4=preferences, then complete
    const MENTOR_STEPS = 5;
    const MENTEE_STEPS = 4;
 
    protected $fillable = [
        'name', 'email', 'password', 'role',
        'wallet_balance', 'bio', 'expertise', 'field', 'college', 'year',
        'gender', 'rating', 'total_sessions', 'avatar_url', 'phone', 'bank_details', 'location',
        'linkedin', 'company', 'designation', 'experience_years',
        'is_active', 'rate_per_minute', 'assigned_mentor_id',
        'subscription_plan', 'mentor_status', 'education_stream',
        'career_goals', 'strengths', 'preferences',
        'onboarding_step', 'onboarding_completed', 'isVerifiedEmail',
        'approved_by', 'approved_at', 'rejection_reason', 'has_pending_changes',
    ];
 
    protected $hidden = ['password', 'remember_token'];
 
    protected $casts = [
        'expertise'            => 'array',
        'career_goals'         => 'array',
        'strengths'            => 'array',
        'preferences'          => PreferencesCast::class,
        'is_active'            => 'boolean',
        'onboarding_completed' => 'boolean',
        'has_pending_changes'  => 'boolean',
        'wallet_balance'       => 'decimal:2',
        'rating'               => 'decimal:2',
        'rate_per_minute'      => 'decimal:2',
        'approved_at'          => 'datetime',
        'email_verified_at'    => 'datetime',
    ];

    public function getAuthPassword(): string
    {
        return $this->password;
    }

    public function preferencesForResponse(): object
    {
        $preferences = $this->preferences;

        if (! is_array($preferences) || array_is_list($preferences) || $preferences === []) {
            return new \stdClass();
        }

        return (object) $preferences;
    }

    public function getAvatarUrlAttribute(?string $value): ?string
    {
        return \App\Services\PublicFileStorage::url($value);
    }

    public function only($attributes)
    {
        $attributes = is_array($attributes) ? $attributes : func_get_args();
        $results = [];

        foreach ($attributes as $attribute) {
            if ($attribute === 'preferences') {
                $results[$attribute] = $this->preferencesForResponse();
                continue;
            }

            $results[$attribute] = $this->getAttribute($attribute);
        }

        return $results;
    }

    public function toArray(): array
    {
        $array = parent::toArray();
        $array['preferences'] = $this->preferencesForResponse();

        return $array;
    }
 
    // ── Role helpers ──────────────────────────────────────────
    public function isMentor(): bool   { return $this->role === 'mentor'; }
    public function isMentee(): bool   { return $this->role === 'mentee'; }
    public function isAdmin(): bool    { return $this->role === 'admin'; }
 
    // ── Mentor approval helpers ───────────────────────────────
    public function isPendingApproval(): bool  { return $this->mentor_status === self::MENTOR_STATUS_PENDING; }
    public function isApproved(): bool         { return $this->mentor_status === self::MENTOR_STATUS_APPROVED; }
    public function isRejected(): bool         { return $this->mentor_status === self::MENTOR_STATUS_REJECTED; }
    public function isSuspended(): bool        { return $this->mentor_status === self::MENTOR_STATUS_SUSPENDED; }
 
    // ── Onboarding helpers ────────────────────────────────────
    public function getOnboardingTotalStepsAttribute(): int
    {
        return $this->isMentor() ? self::MENTOR_STEPS : self::MENTEE_STEPS;
    }
 
    public function getOnboardingProgressAttribute(): int
    {
        if ($this->onboarding_completed) return 100;
        return (int) round(($this->onboarding_step / $this->onboarding_total_steps) * 100);
    }
 
    public function needsOnboarding(): bool
    {
        return !$this->onboarding_completed;
    }
 
    // ── Relationships ─────────────────────────────────────────
    public function assignedMentor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_mentor_id');
    }
 
    public function assignedMentees(): HasMany
    {
        return $this->hasMany(User::class, 'assigned_mentor_id');
    }
 
    public function approvedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'approved_by');
    }
 
    public function pendingChanges(): HasMany
    {
        return $this->hasMany(MentorPendingChange::class, 'mentor_id');
    }
 
    public function latestPendingChange(): HasOne
    {
        return $this->hasOne(MentorPendingChange::class, 'mentor_id')
            ->where('status', 'pending')
            ->latest();
    }
 
    public function mentorSessions(): HasMany
    {
        return $this->hasMany(ConsultationSession::class, 'mentor_id');
    }
 
    public function menteeSessions(): HasMany
    {
        return $this->hasMany(ConsultationSession::class, 'mentee_id');
    }
 
    public function enrollments(): HasMany
    {
        return $this->hasMany(MenteeEnrollment::class, 'mentee_id');
    }

    public function channels(): BelongsToMany
    {
        return $this->belongsToMany(Channel::class, 'channel_members')
            ->withPivot(['role', 'last_read_at', 'muted'])
            ->withTimestamps();
    }

    public function channelInvitations(): HasMany
    {
        return $this->hasMany(ChannelInvitation::class);
    }

    // ── Scopes ────────────────────────────────────────────────
    public function scopeMentors(Builder $q): Builder  { return $q->where('role', 'mentor'); }
    public function scopeMentees(Builder $q): Builder  { return $q->where('role', 'mentee'); }
    public function scopeActive(Builder $q): Builder   { return $q->where('is_active', true); }
    public function scopeApproved(Builder $q): Builder { return $q->where('mentor_status', 'approved'); }
    public function scopePendingApproval(Builder $q): Builder { return $q->where('mentor_status', 'pending'); }
 
    // ── Accessors ─────────────────────────────────────────────
    public function getHourlyRateAttribute(): float
    {
        return round($this->rate_per_minute * 60, 2);
    }
 
    public function getAvgRatingAttribute(): float
    {
        return (float) $this->rating;
    }
 
    public function getIsVerifiedAttribute(): bool
    {
        return $this->mentor_status === self::MENTOR_STATUS_APPROVED;
    }
 
    // ── Mentor approval flow ──────────────────────────────────
    public function approve(int $adminId): void
    {
        $this->update([
            'mentor_status' => self::MENTOR_STATUS_APPROVED,
            'approved_by'   => $adminId,
            'approved_at'   => now(),
            'rejection_reason' => null,
            'is_active'     => true,
        ]);
    }
 
    public function reject(int $adminId, string $reason): void
    {
        $this->update([
            'mentor_status'    => self::MENTOR_STATUS_REJECTED,
            'approved_by'      => $adminId,
            'approved_at'      => now(),
            'rejection_reason' => $reason,
            'is_active'        => false,
        ]);
    }
 
    public function suspend(string $reason = ''): void
    {
        $this->update([
            'mentor_status' => self::MENTOR_STATUS_SUSPENDED,
            'is_active'     => false,
            'rejection_reason' => $reason,
        ]);
    }

    /**
     * Clear unique credentials so the same email/phone can be reused after account deletion.
     */
    public function releaseCredentialsForDeletion(): void
    {
        $this->update([
            'is_active' => false,
            'email'     => 'deleted_' . $this->id . '_' . now()->timestamp . '@deleted.vedrix.local',
            'phone'     => null,
        ]);
    }

    public function deleteAccount(): void
    {
        $this->tokens()->delete();
        $this->releaseCredentialsForDeletion();
        $this->delete();
    }
 
    /**
     * Request a profile change — puts it in queue instead of saving directly.
     */
    public function requestProfileChange(array $changes): MentorPendingChange
    {
        // Cancel any previous pending request
        $this->pendingChanges()->pending()->delete();
 
        $pending = MentorPendingChange::create([
            'mentor_id' => $this->id,
            'changes'   => $changes,
            'status'    => MentorPendingChange::STATUS_PENDING,
        ]);
 
        $this->update(['has_pending_changes' => true]);
 
        return $pending;
    }
 
    /**
     * Recalculate rating from session reviews.
     */
    public function recalculateRating(): void
    {
        $avg = SessionReview::whereHas('session', fn($q) => $q->where('mentor_id', $this->id))
            ->where('reviewer_role', 'mentee')
            ->avg('overall_rating');
        $this->update(['rating' => round($avg ?? 0, 2)]);
    }

}