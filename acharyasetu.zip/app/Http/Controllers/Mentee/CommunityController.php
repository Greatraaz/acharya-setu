<?php

namespace App\Http\Controllers\Mentee;

use App\Http\Controllers\Controller;
use App\Models\Channel;
use App\Models\User;
use App\Support\ChannelIndexQuery;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CommunityController extends Controller
{
    public function index(Request $request)
    {
        $user = Auth::user();
        $channels = ChannelIndexQuery::paginate($user, $request, 18);

        return view('frontend.mentee.community', compact('channels'));
    }

    public function show(Channel $channel)
    {
        $user = Auth::user();
        abort_unless($channel->canAccess($user), 403);

        if ($channel->isMember($user)) {
            $channel->markRead($user);
        }

        $messages = $channel->messagesForUser($user)
            ->latest()
            ->paginate(30)
            ->withQueryString();

        $channels = Channel::visibleTo($user)
            ->withCount(['allMessages', 'members'])
            ->latest()
            ->get()
            ->map(function (Channel $ch) use ($user) {
                $ch->unread_count = $ch->isMember($user) ? $ch->unreadCountFor($user) : 0;

                return $ch;
            });

        $members = $channel->members()
            ->select('users.id', 'users.name', 'users.avatar_url', 'users.role')
            ->orderByPivot('role')
            ->get();

        $inviteCandidates = User::query()
            ->whereIn('role', ['mentor', 'mentee'])
            ->where('is_active', true)
            ->whereNotIn('id', $members->pluck('id'))
            ->orderBy('name')
            ->limit(200)
            ->get(['id', 'name', 'role']);

        $isMember   = $channel->isMember($user);
        $isAdmin    = $channel->isAdmin($user)
            || (int) $channel->created_by === (int) $user->id
            || $user->isAdmin();
        $isCreator  = (int) $channel->created_by === (int) $user->id;

        return view('frontend.mentee.community-show', compact(
            'channel', 'messages', 'channels', 'members',
            'inviteCandidates', 'isMember', 'isAdmin', 'isCreator'
        ));
    }

    public function join(Channel $channel)
    {
        $user = Auth::user();

        abort_if($channel->type === Channel::TYPE_PRIVATE, 403, 'This is a private channel.');

        if ($channel->isRemoved($user)) {
            return back()->with('error', 'You were removed from this channel. Ask a mentor to invite you again.');
        }

        if (! $channel->isMember($user)) {
            $channel->addMember($user, Channel::ROLE_MENTEE);
        }

        return redirect()
            ->route('mentee.community.show', $channel->slug)
            ->with('success', 'Joined channel.');
    }

    public function leave(Channel $channel)
    {
        $user = Auth::user();

        if ((int) $channel->created_by === (int) $user->id) {
            return back()->with('error', 'Channel creator cannot leave.');
        }

        $channel->members()->detach($user->id);

        return redirect()
            ->route('mentee.community.index')
            ->with('success', 'Left channel.');
    }
}
