<?php

namespace App\Http\Controllers\Mentee;

use App\Http\Controllers\Controller;
use App\Services\MenteeOnboardingService;
use App\Support\IndianPhone;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class OnboardingController extends Controller
{
    public function __construct(private readonly MenteeOnboardingService $onboarding)
    {
    }

    public function show(int $step)
    {
        $user = auth()->user();
        if ($user->onboarding_completed) {
            return redirect()->route('mentee.dashboard');
        }
        $streamCatalog = MenteeOnboardingService::streamCatalog();
        $trackSuggestions = collect(array_keys($streamCatalog));
        $tracks = old('tracks', $this->onboarding->menteeTracks($user->id) ?: ($user->career_goals ?? []));
        $preferences = $user->preferences ?? [];

        return view('frontend.mentee.steps', compact('step', 'streamCatalog', 'trackSuggestions', 'tracks', 'preferences'));
    }

    public function saveStep1(Request $request)
    {
        if ($done = $this->alreadyComplete($request)) {
            return $done;
        }

        $data = $request->validate([
            'name'   => 'required|string|max:100',
            'gender' => 'nullable|in:male,female,other',
            'phone'  => IndianPhone::rules(),
            'address'=> 'required|string|max:200',
            'avatar' => 'nullable|image|mimes:jpeg,png,webp,jpg|max:2048',
        ]);

        $user = auth()->user();

        if (array_key_exists('phone', $data)) {
            $data['phone'] = IndianPhone::normalize($data['phone']);
        }

        if ($request->hasFile('avatar')) {
            if ($user->avatar_url && str_starts_with($user->avatar_url, '/storage/')) {
                Storage::disk('public')->delete(str_replace('/storage/', '', $user->avatar_url));
            }
            $path = $request->file('avatar')->store('avatars', 'public');
            $data['avatar_url'] = '/storage/' . $path;
        }

        $data['location'] = $data['address'] ?? $user->location;
        unset($data['address'], $data['avatar']);

        $user->update(array_merge($data, ['onboarding_step' => 1]));

        return $this->next($request, 2);
    }

    public function saveStep2(Request $request)
    {
        if ($done = $this->alreadyComplete($request)) {
            return $done;
        }

        $data = $request->validate([
            'education_stream' => 'required|string|max:100',
            'field'            => 'nullable|string|max:100',
            'college'          => 'nullable|string|max:200',
            'year'             => 'nullable|string|max:50',
        ]);

        $user = auth()->user();
        $user->update(array_merge($data, ['onboarding_step' => 2]));

        if (! empty($data['education_stream'])) {
            $this->onboarding->assignCatalogStream($user->fresh(), $data['education_stream']);
        }

        return $this->next($request, 3);
    }

    public function saveStep3(Request $request)
    {
        if ($done = $this->alreadyComplete($request)) {
            return $done;
        }

        $data = $request->validate([
            'tracks'   => 'required|array|min:1',
            'tracks.*' => 'string|max:100',
        ]);

        $tracks = collect($data['tracks'])
            ->map(fn ($track) => trim((string) $track))
            ->filter()
            ->unique(fn ($track) => Str::lower($track))
            ->values();

        if ($tracks->isEmpty()) {
            $msg = 'Please provide at least one valid track.';
            if ($request->ajax()) {
                return response()->json(['message' => $msg], 422);
            }
            return back()->withErrors(['tracks' => $msg])->withInput();
        }

        $this->onboarding->syncMenteeTracks(auth()->id(), $tracks->all());
        auth()->user()->update(['onboarding_step' => 3]);

        return $this->next($request, 4);
    }

    public function saveStep4(Request $request)
    {
        if ($done = $this->alreadyComplete($request)) {
            return $done;
        }

        $data = $request->validate([
            'weekly_time_commitment' => 'required|string',
            'monthly_budget'         => 'nullable|string',
            'preferred_language'     => 'required|string',
            'mentoring_format'       => 'nullable|string',
            'session_modes'          => 'nullable|array',
            'session_modes.*'        => 'in:video,audio,chat,in_person',
        ]);

        $user = auth()->user();
        $preferences = array_merge($user->preferences ?? [], array_filter([
            'weekly_time_commitment' => $data['weekly_time_commitment'],
            'monthly_budget'         => $data['monthly_budget'] ?? null,
            'preferred_language'     => $data['preferred_language'],
            'mentoring_format'       => $data['mentoring_format'] ?? null,
        ], fn ($value) => $value !== null && $value !== ''));

        $user->update([
            'preferences'     => $preferences,
            'onboarding_step' => 4,
        ]);

        return $this->complete($request);
    }

    public function complete(Request $request)
    {
        $user = auth()->user();
        $result = $this->onboarding->complete($user);

        if (! $result['completed']) {
            $msg = 'Please complete all onboarding steps before finishing.';
            if ($request->ajax()) {
                return response()->json([
                    'message'        => $msg,
                    'missing_fields' => $result['missing'],
                ], 422);
            }
            return back()->with('error', $msg);
        }

        $redirect = route('mentee.dashboard');
        $message = ! empty($result['already'])
            ? 'Onboarding is already complete.'
            : ($result['assigned']
                ? 'Onboarding complete! A mentor has been assigned to you.'
                : 'Onboarding complete!');
        if ($request->ajax()) {
            return response()->json([
                'message'  => $message,
                'redirect' => $redirect,
            ]);
        }

        return redirect($redirect)->with('success', $message);
    }

    private function alreadyComplete(Request $request)
    {
        if (! auth()->user()->onboarding_completed) {
            return null;
        }

        $redirect = route('mentee.dashboard');
        if ($request->ajax() || $request->wantsJson()) {
            return response()->json([
                'message'  => 'Onboarding is already complete.',
                'redirect' => $redirect,
            ], 422);
        }

        return redirect($redirect);
    }

    private function next(Request $request, int $step)
    {
        $redirect = route('mentee.onboarding', ['step' => $step]);
        if ($request->ajax()) {
            return response()->json(['message' => 'Saved!', 'redirect' => $redirect]);
        }
        return redirect($redirect);
    }
}
