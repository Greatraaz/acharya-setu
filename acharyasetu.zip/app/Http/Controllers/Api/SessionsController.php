<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\{AppSetting, ConsultationSession, SessionNote, User};
use App\Services\SessionBookingService;
use App\Services\SessionCancellationService;
use Carbon\Carbon;
use Illuminate\Http\{JsonResponse, Request};
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use InvalidArgumentException;

class SessionsController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $u = $request->user();
        ConsultationSession::expireMissedSessions(
            $u->role === 'mentor' ? $u->id : null,
            $u->role === 'mentee' ? $u->id : null
        );

        $data = $request->validate([
            'status'    => 'nullable|in:'.implode(',', array_keys(ConsultationSession::STATUSES)),
            'date'      => 'nullable|date',
            'date_from' => 'nullable|date',
            'date_to'   => 'nullable|date|after_or_equal:date_from',
            'search'    => 'nullable|string|max:100',
            'q'         => 'nullable|string|max:100',
            'per_page'  => 'nullable|integer|min:1|max:100',
        ]);

        $search  = trim((string) ($data['search'] ?? $data['q'] ?? ''));
        $perPage = $data['per_page'] ?? 20;

        $f = $u->role === 'mentor' ? 'mentor_id' : 'mentee_id';
        $query = ConsultationSession::where($f, $u->id)
            ->with([
                'mentor:id,name,avatar_url,gender',
                'mentee:id,name,avatar_url',
                'sessionInvoice',
                'notes' => fn ($q) => $q->with('author:id,name,role,avatar_url')->latest(),
            ])
            ->when(! empty($data['status']), fn ($q) => $q->where('status', $data['status']))
            ->when(! empty($data['date']), fn ($q) => $q->whereDate('scheduled_at', $data['date']))
            ->when(! empty($data['date_from']), fn ($q) => $q->whereDate('scheduled_at', '>=', $data['date_from']))
            ->when(! empty($data['date_to']), fn ($q) => $q->whereDate('scheduled_at', '<=', $data['date_to']))
            ->when($search !== '', function ($inner) use ($search, $u) {
                $inner->where(function ($q) use ($search, $u) {
                    $q->where('title', 'like', '%'.$search.'%')
                        ->orWhere('booking_ref', 'like', '%'.$search.'%');
                    if ($u->role === 'mentee') {
                        $q->orWhereHas('mentor', fn ($m) => $m->where('name', 'like', '%'.$search.'%'));
                    } else {
                        $q->orWhereHas('mentee', fn ($m) => $m->where('name', 'like', '%'.$search.'%'));
                    }
                });
            })
            ->orderByDesc('scheduled_at')
            ->orderByDesc('id');

        $paginator = $query->paginate($perPage)->withQueryString();

        $sessions = collect($paginator->items())->map(fn ($s) => [
            'id'             => $s->id,
            'mentorId'       => $s->mentor_id,
            'mentorName'     => $s->mentor?->name,
            'mentorAvatar'   => $s->mentor?->avatar_url,
            'mentorGender'   => $s->mentor?->gender,
            'menteeId'       => $s->mentee_id,
            'menteeName'     => $s->mentee?->name,
            'menteeAvatar'   => $s->mentee?->avatar_url,
            'date'           => $s->scheduled_at?->format('d M Y'),
            'time'           => $s->scheduled_at?->format('h:i A'),
            'scheduledAt'    => $s->scheduled_at?->toDateTimeString(),
            'duration'       => $s->duration_minutes,
            'status'         => $s->status,
            'topic'          => $s->title,
            'agenda'         => $s->agenda,
            'notes'          => $s->notes->map(fn (SessionNote $note) => $this->formatNote($note))->values(),
            'meetingLink'    => $s->meeting_link,
            'channel'        => $s->meeting_channel,
            'canJoinCall'    => $s->canJoinCall(),
            'amountPaid'     => (float) $s->amount,
            'listAmount'     => (float) $s->listAmount(),
            'couponDiscount' => (float) ($s->coupon_discount ?? 0),
            'mentorEarning'  => (float) $s->mentor_earning,
            'platformFee'    => (float) $s->payoutBreakdown()['platform_fee'],
            'paymentStatus'  => $s->payment_status,
            'paymentMethod'  => $s->payment_method,
            'paymentMethodLabel' => $s->paymentMethodLabel(),
            'walletAmount'   => (float) ($s->wallet_amount ?? 0),
            'razorpayAmount' => (float) ($s->razorpay_amount ?? 0),
            'invoice'        => $s->sessionInvoice ? [
                'id'             => $s->sessionInvoice->id,
                'invoice_number' => $s->sessionInvoice->invoice_number,
            ] : null,
            'bookingRef'     => $s->booking_ref,
        ])->values();

        return response()->json([
            'status'     => true,
            'statuscode' => 200,
            'sessions'   => $sessions,
            'statuses'   => ConsultationSession::STATUSES,
            'meta'       => [
                'current_page' => $paginator->currentPage(),
                'last_page'    => $paginator->lastPage(),
                'per_page'     => $paginator->perPage(),
                'total'        => $paginator->total(),
            ],
            'filters'    => [
                'status'    => $data['status'] ?? null,
                'date'      => $data['date'] ?? null,
                'date_from' => $data['date_from'] ?? null,
                'date_to'   => $data['date_to'] ?? null,
                'search'    => $search !== '' ? $search : null,
            ],
        ]);
    }

    /**
     * Book a session (mentee).
     * Wallet-first flow:
     * - If wallet balance is sufficient, deduct from wallet and confirm immediately.
     * - Otherwise, create Razorpay order and wait for verifyPayment().
     * POST /api/v1/mentee/sessions
     */
    public function store(Request $request, SessionBookingService $booking): JsonResponse
    {
        $data = $request->validate([
            'mentor_id'      => 'required|exists:users,id',
            'date'           => 'required|date|after_or_equal:today',
            'time'           => 'required|string',
            'duration'       => 'required|integer|in:'.implode(',', ConsultationSession::BOOKING_DURATIONS),
            'title'          => 'required|string|max:255',
            'agenda'         => 'nullable|string|max:1000',
            'coupon_code'    => 'nullable|string|max:40',
            'payment_method' => 'nullable|in:wallet,razorpay,hybrid',
        ]);

        $result = $booking->book($request->user(), $data, 'api');
        $payload = $result['payload'];

        if (! $result['ok']) {
            return response()->json(array_merge([
                'status'     => false,
                'statuscode' => $result['http'],
            ], $payload), $result['http']);
        }

        // Payment choice: no razorpay keys in response
        if (! empty($payload['requires_payment_choice'])) {
            return response()->json([
                'status'     => true,
                'statuscode' => 200,
                'message'    => $payload['message'],
                'data'       => $payload,
            ], 200);
        }

        // Razorpay checkout needed
        if (! empty($payload['requires_payment'])) {
            return response()->json([
                'status'     => true,
                'statuscode' => 201,
                'message'    => $payload['message'],
                'data'       => $payload,
            ], 201);
        }

        return response()->json([
            'status'     => true,
            'statuscode' => $result['http'],
            'message'    => $payload['message'],
            'data'       => $payload,
        ], $result['http']);
    }

    /**
     * Verify Razorpay payment and confirm the session.
     * POST /api/v1/mentee/sessions/verify
     */
    public function verifyPayment(Request $request, SessionBookingService $booking): JsonResponse
    {
        $data = $request->validate([
            'razorpay_order_id'   => 'required|string',
            'razorpay_payment_id' => 'required|string',
            'razorpay_signature'  => 'required|string',
        ]);

        $result = $booking->verify($request->user(), $data);
        $payload = $result['payload'];

        if (! $result['ok']) {
            return response()->json(array_merge([
                'status'     => false,
                'statuscode' => $result['http'],
            ], $payload), $result['http']);
        }

        return response()->json([
            'status'     => true,
            'statuscode' => 200,
            'message'    => $payload['message'],
            'data'       => $payload,
        ]);
    }

    /**
     * Personal notes only (private — matches web "My Personal Notes").
     * Frontend already uses these routes for personal notes.
     * GET /api/v1/{mentor|mentee}/sessions/{id}/notes
     */
    public function notes(Request $request, int $id): JsonResponse
    {
        $session = $this->findOwnedSession($request, $id);
        $userId  = (int) $request->user()->id;

        $notes = $session->notes()
            ->with('author:id,name,role,avatar_url')
            ->where('author_id', $userId)
            ->where('is_shared', false)
            ->latest()
            ->get()
            ->map(fn (SessionNote $note) => $this->formatNote($note));

        $myNote = $notes->first();

        return response()->json([
            'status'     => true,
            'statuscode' => 200,
            'session_id' => $session->id,
            'count'      => $notes->count(),
            'my_note'    => $myNote,
            'notes'      => $notes,
        ]);
    }

    /**
     * Create / upsert personal note (is_shared = false).
     * POST /api/v1/{mentor|mentee}/sessions/{id}/notes
     * Body: { "content": "..." }
     */
    public function addNote(Request $request, int $id): JsonResponse
    {
        $session = $this->findOwnedSession($request, $id);
        $userId  = (int) $request->user()->id;

        $data = $request->validate([
            'content' => 'required|string|max:65535',
        ]);

        $note = $session->notes()
            ->where('author_id', $userId)
            ->where('is_shared', false)
            ->where('type', 'note')
            ->latest()
            ->first();

        if ($note) {
            $note->update([
                'content'      => $data['content'],
                'resource_url' => null,
            ]);
            $statusCode = 200;
            $message = 'Personal note updated.';
        } else {
            $note = $session->notes()->create([
                'author_id'    => $userId,
                'type'         => 'note',
                'content'      => $data['content'],
                'resource_url' => null,
                'is_shared'    => false,
            ]);
            $statusCode = 201;
            $message = 'Personal note saved.';
        }

        $note->load('author:id,name,role,avatar_url');

        return response()->json([
            'status'     => true,
            'statuscode' => $statusCode,
            'message'    => $message,
            'note'       => $this->formatNote($note),
        ], $statusCode);
    }

    /**
     * Update own personal note.
     * PATCH /api/v1/{mentor|mentee}/sessions/{id}/notes/{noteId}
     */
    public function updateNote(Request $request, int $id, int $noteId): JsonResponse
    {
        $session = $this->findOwnedSession($request, $id);

        $note = $session->notes()
            ->where('id', $noteId)
            ->where('author_id', $request->user()->id)
            ->where('is_shared', false)
            ->firstOrFail();

        $data = $request->validate([
            'content' => 'required|string|max:65535',
        ]);

        $note->update(['content' => $data['content']]);
        $note->load('author:id,name,role,avatar_url');

        return response()->json([
            'status'     => true,
            'statuscode' => 200,
            'message'    => 'Personal note updated.',
            'note'       => $this->formatNote($note),
        ]);
    }

    /**
     * Delete own personal note.
     * DELETE /api/v1/{mentor|mentee}/sessions/{id}/notes/{noteId}
     */
    public function destroyNote(Request $request, int $id, int $noteId): JsonResponse
    {
        $session = $this->findOwnedSession($request, $id);

        $note = $session->notes()
            ->where('id', $noteId)
            ->where('author_id', $request->user()->id)
            ->where('is_shared', false)
            ->firstOrFail();

        $note->delete();

        return response()->json([
            'status'     => true,
            'statuscode' => 200,
            'message'    => 'Personal note deleted.',
        ]);
    }

    /**
     * Shared notes visible to both mentor and mentee (matches web "Shared Session Notes").
     * GET /api/v1/{mentor|mentee}/sessions/{id}/shared-notes
     */
    public function sharedNotes(Request $request, int $id): JsonResponse
    {
        $session = $this->findOwnedSession($request, $id);
        $userId  = (int) $request->user()->id;

        $notes = $session->notes()
            ->with('author:id,name,role,avatar_url')
            ->where('is_shared', true)
            ->latest()
            ->get()
            ->map(fn (SessionNote $note) => $this->formatNote($note));

        $mySharedNote = $notes->first(fn ($n) => (int) $n['author_id'] === $userId);

        return response()->json([
            'status'         => true,
            'statuscode'     => 200,
            'session_id'     => $session->id,
            'count'          => $notes->count(),
            'my_shared_note' => $mySharedNote,
            'notes'          => $notes,
        ]);
    }

    /**
     * Create / upsert own shared note (visible to the other party).
     * POST /api/v1/{mentor|mentee}/sessions/{id}/shared-notes
     * Body: { "content": "Key discussion points…", "type": "note" }
     */
    public function saveSharedNote(Request $request, int $id): JsonResponse
    {
        $session = $this->findOwnedSession($request, $id);
        $userId  = (int) $request->user()->id;

        $data = $request->validate([
            'content' => 'required|string|max:65535',
            'type'    => 'nullable|in:note,resource,action_item',
        ]);

        $type = $data['type'] ?? 'note';

        $note = $session->notes()
            ->where('author_id', $userId)
            ->where('type', $type)
            ->where('is_shared', true)
            ->latest()
            ->first();

        $payload = [
            'content'   => $data['content'],
            'is_shared' => true,
            'type'      => $type,
        ];

        if ($note) {
            $note->update($payload);
            $statusCode = 200;
            $message = 'Shared notes saved.';
        } else {
            $note = $session->notes()->create(array_merge($payload, [
                'author_id'    => $userId,
                'resource_url' => null,
            ]));
            $statusCode = 201;
            $message = 'Shared notes saved.';
        }

        $note->load('author:id,name,role,avatar_url');

        return response()->json([
            'status'     => true,
            'statuscode' => $statusCode,
            'message'    => $message,
            'note'       => $this->formatNote($note),
        ], $statusCode);
    }

    /**
     * Update own shared note by id.
     * PATCH /api/v1/{mentor|mentee}/sessions/{id}/shared-notes/{noteId}
     */
    public function updateSharedNote(Request $request, int $id, int $noteId): JsonResponse
    {
        $session = $this->findOwnedSession($request, $id);

        $note = $session->notes()
            ->where('id', $noteId)
            ->where('author_id', $request->user()->id)
            ->where('is_shared', true)
            ->firstOrFail();

        $data = $request->validate([
            'content' => 'required|string|max:65535',
            'type'    => 'nullable|in:note,resource,action_item',
        ]);

        $note->update(array_filter([
            'content' => $data['content'],
            'type'    => $data['type'] ?? null,
        ], fn ($v) => $v !== null));

        $note->load('author:id,name,role,avatar_url');

        return response()->json([
            'status'     => true,
            'statuscode' => 200,
            'message'    => 'Shared note updated.',
            'note'       => $this->formatNote($note),
        ]);
    }

    /**
     * Delete own shared note.
     * DELETE /api/v1/{mentor|mentee}/sessions/{id}/shared-notes/{noteId}
     */
    public function destroySharedNote(Request $request, int $id, int $noteId): JsonResponse
    {
        $session = $this->findOwnedSession($request, $id);

        $note = $session->notes()
            ->where('id', $noteId)
            ->where('author_id', $request->user()->id)
            ->where('is_shared', true)
            ->firstOrFail();

        $note->delete();

        return response()->json([
            'status'     => true,
            'statuscode' => 200,
            'message'    => 'Shared note deleted.',
        ]);
    }

    public function update(Request $request, int $id, SessionCancellationService $cancellations): JsonResponse
    {
        try {
            $s = $this->findOwnedSession($request, $id);
            $d = $request->validate([
                'status' => 'sometimes|in:upcoming,completed,cancelled',
                'notes'  => 'nullable|string',
            ]);

            if (($d['status'] ?? null) === 'completed') {
                $s->complete();
                $s->refresh();
            } elseif (($d['status'] ?? null) === 'cancelled') {
                $role = $request->user()->role === 'mentor'
                    ? SessionCancellationService::ROLE_MENTOR
                    : SessionCancellationService::ROLE_MENTEE;
                $result = $cancellations->cancel($s, $request->user(), $role, $d['notes'] ?? null);
                $s = $result['session'];

                return response()->json([
                    'status'     => true,
                    'statuscode' => 200,
                    'message'    => $result['message'],
                    'session'    => $s,
                    'settlement' => [
                        'policy'                => $result['policy'],
                        'refund_percent'        => $result['refund_percent'],
                        'wallet_refunded'       => $result['wallet_refunded'],
                        'razorpay_refunded'     => $result['razorpay_refunded'],
                        'coupon_restored'       => $result['coupon_restored'],
                        'plan_benefit_restored' => $result['plan_benefit_restored'],
                        'mentor_credited'       => $result['mentor_credited'],
                    ],
                ]);
            } else {
                $s->update($d);
            }

            return response()->json([
                'status'     => true,
                'statuscode' => 200,
                'session'    => $s,
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'status'     => false,
                'statuscode' => 404,
                'message'    => 'Session not found',
            ], 404);
        } catch (InvalidArgumentException $e) {
            return response()->json([
                'status'     => false,
                'statuscode' => 422,
                'message'    => $e->getMessage(),
            ], 422);
        } catch (\Throwable $e) {
            return response()->json([
                'status'     => false,
                'statuscode' => 400,
                'message'    => $e->getMessage(),
            ], 400);
        }
    }

    public function destroy(Request $request, int $id, SessionCancellationService $cancellations): JsonResponse
    {
        try {
            $session = $this->findOwnedSession($request, $id);
            $role = $request->user()->role === 'mentor'
                ? SessionCancellationService::ROLE_MENTOR
                : SessionCancellationService::ROLE_MENTEE;

            $result = $cancellations->cancel(
                $session,
                $request->user(),
                $role,
                $request->input('reason')
            );

            return response()->json([
                'status'     => true,
                'statuscode' => 200,
                'message'    => $result['message'],
                'settlement' => [
                    'policy'                => $result['policy'],
                    'refund_percent'        => $result['refund_percent'],
                    'wallet_refunded'       => $result['wallet_refunded'],
                    'razorpay_refunded'     => $result['razorpay_refunded'],
                    'coupon_restored'       => $result['coupon_restored'],
                    'plan_benefit_restored' => $result['plan_benefit_restored'],
                    'mentor_credited'       => $result['mentor_credited'],
                ],
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'status'     => false,
                'statuscode' => 404,
                'message'    => 'Session not found',
            ], 404);
        } catch (InvalidArgumentException $e) {
            return response()->json([
                'status'     => false,
                'statuscode' => 422,
                'message'    => $e->getMessage(),
            ], 422);
        } catch (\Throwable $e) {
            return response()->json([
                'status'     => false,
                'statuscode' => 400,
                'message'    => $e->getMessage(),
            ], 400);
        }
    }

    public function getAgoraToken(Request $request, $channel): JsonResponse
    {
        $session = ConsultationSession::query()
            ->where('meeting_channel', $channel)
            ->where(function ($q) use ($request) {
                $q->where('mentor_id', $request->user()->id)
                  ->orWhere('mentee_id', $request->user()->id);
            })
            ->with(['mentor:id,name,avatar_url', 'mentee:id,name,avatar_url'])
            ->first();

        if (! $session) {
            return response()->json([
                'status'     => false,
                'statuscode' => 404,
                'message'    => 'Session not found for this channel.',
            ], 404);
        }

        return $this->agoraTokenResponse($request, $session);
    }

    public function agoraToken(Request $request, int $id): JsonResponse
    {
        try {
            $session = $this->findOwnedSession($request, $id);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'status'     => false,
                'statuscode' => 404,
                'message'    => 'Session not found',
            ], 404);
        }

        $session->load(['mentor:id,name,avatar_url', 'mentee:id,name,avatar_url']);

        return $this->agoraTokenResponse($request, $session);
    }

    private function agoraTokenResponse(Request $request, ConsultationSession $session): JsonResponse
    {
        try {
            $payload = app(\App\Services\AgoraService::class)->issueToken($request->user(), $session);
        } catch (\Symfony\Component\HttpKernel\Exception\HttpException $e) {
            return response()->json([
                'status'     => false,
                'statuscode' => $e->getStatusCode(),
                'message'    => $e->getMessage(),
            ], $e->getStatusCode());
        }

        return response()->json(array_merge([
            'status'     => true,
            'statuscode' => 200,
        ], $payload));
    }

    private function findOwnedSession(Request $request, int $id): ConsultationSession
    {
        $user = $request->user();
        $field = $user->role === 'mentor' ? 'mentor_id' : 'mentee_id';

        return ConsultationSession::where('id', $id)
            ->where($field, $user->id)
            ->firstOrFail();
    }

    private function formatNote(SessionNote $note): array
    {
        return [
            'id'           => $note->id,
            'session_id'   => $note->session_id,
            'author_id'    => $note->author_id,
            'type'         => $note->type,
            'content'      => $note->content,
            'resource_url' => $note->resource_url,
            'is_shared'    => (bool) $note->is_shared,
            'created_at'   => $note->created_at,
            'updated_at'   => $note->updated_at,
            'author'       => $note->relationLoaded('author') && $note->author ? [
                'id'         => $note->author->id,
                'name'       => $note->author->name,
                'role'       => $note->author->role,
                'avatar_url' => $note->author->avatar_url,
            ] : null,
        ];
    }

    private function razorpayCredentials(): array
    {
        $settings = AppSetting::razorpay();

        return [
            'enabled' => $settings['enabled'] ?? true,
            'key'     => $settings['key'] ?: env('RAZORPAY_KEY_ID', ''),
            'secret'  => $settings['secret'] ?: env('RAZORPAY_KEY_SECRET', ''),
        ];
    }

    private function sessionPaymentPayload(
        ConsultationSession $session,
        ?string $razorpayKey,
        ?int $amountPaise
    ): array {
        $payload = [
            'session_id'         => $session->id,
            'booking_ref'        => $session->booking_ref,
            'mentor_id'          => $session->mentor_id,
            'mentee_id'          => $session->mentee_id,
            'scheduled_at'       => $session->scheduled_at?->toDateTimeString(),
            'duration'           => $session->duration_minutes,
            'amount'             => (float) $session->amount,
            'currency'           => $session->currency,
            'payment_status'     => $session->payment_status,
            'status'             => $session->status,
            'meeting_link'       => $session->meeting_link,
            'razorpay_order_id'  => $session->razorpay_order_id,
            'razorpay_payment_id'=> $session->razorpay_payment_id,
        ];

        if ($razorpayKey !== null) {
            $payload['razorpay_key'] = $razorpayKey;
            $payload['amount_paise'] = $amountPaise;
        }

        return $payload;
    }
}
